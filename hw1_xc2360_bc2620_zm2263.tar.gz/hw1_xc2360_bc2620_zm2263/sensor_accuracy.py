from gopigo import *
import time

servo(90)
d = us_dist(15)
print d
