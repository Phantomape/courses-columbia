This is a Lab 1 submission for group 22

Team Members: Ziyi Mu zm2263, Xucheng Chen , Benjamin Carlin

Question 1: Done. 

Question 2: Code implementation is found in dancing.py.

Question 3: Code implementation is found in sensor_accuracy.py. 
5cm test: 5cm
10cm test: 10-11cm
30cm test: 36-37cm
60cm test: 76-77cm

Question 4: Code implementation is found in beam_width.py. 


Question 5: Code implementation is found in locate_object.py